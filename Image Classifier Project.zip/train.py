import matplotlib.pyplot as plt

import torch
from torch import nn
from torch import optim
import torch.nn.functional as F
from torchvision import datasets, transforms, models

from PIL import Image
import numpy as np
from collections import OrderedDict

import argparse

data_dir = 'flowers'
train_dir = data_dir + '/train'
valid_dir = data_dir + '/valid'
test_dir = data_dir + '/test'


if __name__ == "__main__":

    parser = argparse.ArgumentParser()

    parser.add_argument('--save_dir', type = str, default='.')
    parser.add_argument('--arch', type = str, default="vgg11")
    parser.add_argument('--learning_rate', type = float, default=0.003)
    parser.add_argument('--hidden', type=int, default=500)
    parser.add_argument('--epochs', type=int, default=1)
    parser.add_argument('--gpu', action='store_true')
    args = parser.parse_args()

    learning_rate = args.learning_rate
    hidden_unit = args.hidden

    print('Load the data...')

    train_transforms = transforms.Compose([transforms.RandomRotation(30),
                                       transforms.RandomResizedCrop(224),
                                       transforms.RandomHorizontalFlip(),
                                       transforms.ToTensor(),
                                       transforms.Normalize([0.485, 0.456, 0.406],
                                                            [0.229, 0.224, 0.225])])

    val_transforms = transforms.Compose([transforms.Resize(255),
                                        transforms.CenterCrop(224),
                                        transforms.ToTensor(),
                                        transforms.Normalize([0.485, 0.456, 0.406],
                                                            [0.229, 0.224, 0.225])])

    test_transforms = transforms.Compose([transforms.Resize(255),
                                        transforms.CenterCrop(224),
                                        transforms.ToTensor(),
                                        transforms.Normalize([0.485, 0.456, 0.406],
                                                            [0.229, 0.224, 0.225])])

    # TODO: Load the datasets with ImageFolder
    train_data = datasets.ImageFolder(train_dir, transform=train_transforms)
    val_data = datasets.ImageFolder(valid_dir, transform=val_transforms)
    test_data = datasets.ImageFolder(test_dir, transform=test_transforms)

    # TODO: Using the image datasets and the trainforms, define the dataloaders
    trainloader = torch.utils.data.DataLoader(train_data, batch_size=64, shuffle=True)
    valloader = torch.utils.data.DataLoader(val_data, batch_size=64)
    testloader = torch.utils.data.DataLoader(test_data, batch_size=64)


    print('Building and training the classifier...')
    if args.arch == "vgg11":
        model = models.vgg11(weights=True)
    elif args.arch == "vgg16":
        model = models.vgg16(weights=True)

    for param in model.parameters():
        param.requires_grad = False

    
    classifier = nn.Sequential(OrderedDict([
                            ('fc1', nn.Linear(25088, hidden_unit)),
                            ('relu', nn.ReLU()),
                            ('fc2', nn.Linear(hidden_unit, 102)),
                            ('output', nn.LogSoftmax(dim=1))
                            ]))
    model.classifier = classifier


    if args.gpu:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        device = torch.device("cpu")

    optimizer = optim.Adam(model.classifier.parameters(), lr=learning_rate)
    criterion = nn.NLLLoss()

    model.to(device)


    print('Start trainning!...')
    epochs = args.epochs
    steps = 0
    running_loss = 0
    running_accuracy = 0
    print_every = 5

    for epoch in range(epochs):
        for inputs, labels in trainloader:
            steps += 1
            # Move input and label tensors to the default device
            inputs, labels = inputs.to(device), labels.to(device)
            
            optimizer.zero_grad()
            
            logps = model.forward(inputs)
            loss = criterion(logps, labels)
            loss.backward()
            optimizer.step()

            running_loss += loss.item()
            
            # Calculate accuracy
            ps = torch.exp(logps)
            top_p, top_class = ps.topk(1, dim=1)
            equals = top_class == labels.view(*top_class.shape)
            running_accuracy += torch.mean(equals.type(torch.FloatTensor)).item()
            
            if steps % print_every == 0:
                test_loss = 0
                accuracy = 0
                model.eval()
                with torch.no_grad():
                    for inputs, labels in valloader:
                        inputs, labels = inputs.to(device), labels.to(device)
                        logps = model.forward(inputs)
                        batch_loss = criterion(logps, labels)
                        
                        test_loss += batch_loss.item()
                        
                        # Calculate accuracy
                        ps = torch.exp(logps)
                        top_p, top_class = ps.topk(1, dim=1)
                        equals = top_class == labels.view(*top_class.shape)
                        accuracy += torch.mean(equals.type(torch.FloatTensor)).item()
                        
                print(f"Epoch {epoch+1}/{epochs}.. "
                    f"Train loss: {running_loss/print_every:.3f}.. "
                    f"Val loss: {test_loss/len(valloader):.3f}.. "
                    f"Val accuracy: {accuracy/len(valloader):.3f}.."
                    f"Train accuracy: {running_accuracy/print_every:.3f}")
                running_loss = 0
                running_accuracy = 0
                model.train()


    print('Save the checkpoint...')
    model.class_to_idx = train_data.class_to_idx
    checkpoint = {'input_size': model.classifier[0].in_features,
                'output_size': 102,
                'classifier' : model.classifier,
                'state_dict': model.state_dict(),
                'arch' : args.arch,
                'class_to_idx': model.class_to_idx}
    torch.save(checkpoint, 'checkpoint.pth')

    print('Finish!!')